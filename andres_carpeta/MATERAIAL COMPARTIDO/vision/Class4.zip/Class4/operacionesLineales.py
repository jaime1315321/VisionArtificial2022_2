﻿import numpy as np
import cv2

# Copia de imagen
img = cv2.imread('lena.jpg')
height, width = img.shape[:2]  # Obtenemos sus dimensiones
imgCp = np.zeros((height, width, 3), np.uint8)  # Creamos una imagen nueva

# Seccion a color
for i in range(0, height):
    for j in range(0, width):
        imgCp[i, j] = img[i, j]
'''
cv2.imshow('imagen_resultado', np.hstack([img, imgCp]))
cv2.waitKey(0)
cv2.destroyAllWindows()
'''
# Operador suma
img1 = cv2.imread('s1.jpg')
img2 = cv2.imread('s2.jpg')
#add = (img1//2 + img2//2)
add = cv2.addWeighted(img1, 0.1, img2, 0.8, 0)  # Operador de suma
cv2.imshow('suma', np.hstack([img1, img2, add]))  # Mostramos las imagenes
cv2.waitKey(0)
cv2.destroyAllWindows()

# Operador resta
img3 = cv2.imread('d1.jpg', 0)
img4 = cv2.imread('d2.jpg', 0)
subs = cv2.subtract(img3, img4)  # Operador de resta
#subs = img3 - img4  # Operador de resta
img3Rs = cv2.resize(img3, (0, 0), fx=0.7, fy=0.7)  # Redimensionamiento
img4Rs = cv2.resize(img4, (0, 0), fx=0.7, fy=0.7)  # Redimensionamiento
subsRs = cv2.resize(subs, (0, 0), fx=0.7, fy=0.7)  # Redimensionamiento
cv2.imshow('resta', np.hstack([img3Rs, img4Rs, subsRs]))  # Mostramos las imagenes
cv2.waitKey(0)
cv2.destroyAllWindows()

# Fuente: Documentacion OpenCV

img5 = cv2.imread('d1.jpg', 0)
img6 = cv2.imread('d2.jpg', 0)
div = img5//img6  # Operador de resta
cv2.imshow('div', np.hstack([img5, img6, div]))  # Mostramos las imagenes
cv2.waitKey(0)
cv2.destroyAllWindows()
